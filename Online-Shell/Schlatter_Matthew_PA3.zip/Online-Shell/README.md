Team Members: Matthew Schlatter

To compile, I used the make command with the make file.
Then, I started the server first and on other PuTTY windows,
I opened multiple clients and connected to the server to
test command outputs.